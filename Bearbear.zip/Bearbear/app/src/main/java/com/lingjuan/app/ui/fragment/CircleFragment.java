package com.lingjuan.app.ui.fragment;

import android.view.View;

import com.lingjuan.app.base.BaseFragment;

/**
 * Created by TaoHui on 2018/10/11.
 */

public class CircleFragment extends BaseFragment {
    @Override
    protected void initview(View view) {

    }

    @Override
    protected void initData() {

    }


    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
    }

    @Override
    protected int getlayoutt() {
        return 0;
    }

    @Override
    protected void onStopView() {

    }
}
