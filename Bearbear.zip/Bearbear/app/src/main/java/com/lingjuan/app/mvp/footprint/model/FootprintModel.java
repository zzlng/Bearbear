package com.lingjuan.app.mvp.footprint.model;

/**
 * @author: TaoHui
 * @date: 2019/1/17
 */
public class FootprintModel {

}
