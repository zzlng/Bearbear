package com.lingjuan.app.mvp.footprint.view;

import com.lingjuan.app.mvp.base.BaseViw;

/**
 * @author: TaoHui
 * @date: 2019/1/17
 */
public class Footprint {

    public interface View extends BaseViw {
        void init();
    }






}
